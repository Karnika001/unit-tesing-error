package com.karnika.unittesting.unittesting.data;

public interface SomeDataService {

	int[] retrieveAllData();

}
